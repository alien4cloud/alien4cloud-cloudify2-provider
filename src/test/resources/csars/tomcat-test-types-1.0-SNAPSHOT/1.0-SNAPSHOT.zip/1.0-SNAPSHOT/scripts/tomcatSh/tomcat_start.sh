#!/bin/sh

export JAVA_HOME=/root/java
tomcat/bin/startup.sh