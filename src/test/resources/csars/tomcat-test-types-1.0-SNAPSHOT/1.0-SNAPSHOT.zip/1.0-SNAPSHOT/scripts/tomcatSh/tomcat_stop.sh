#!/bin/sh

export JAVA_HOME=/root/java
tomcat/bin/catalina.sh stop