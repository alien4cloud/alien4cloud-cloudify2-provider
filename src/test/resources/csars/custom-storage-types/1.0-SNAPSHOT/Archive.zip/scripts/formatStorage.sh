#!/bin/bash

sudo mkfs.ext4 $1